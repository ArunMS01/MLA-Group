<footer class="site-footer style-1 bg-light b-1">


  <style>
  @media only screen and (max-width:1399px){
      #whatsapp-chat{
          width:40% !important;
      }
      .whatsapp-chat-body{
          display:none !important;
      }
      .header-chat{
          padding:9px !important;
      }
      input#chat-input, .form-controls{
              height: 34px !important;
              margin-top: 4px !important;
   
    font-size: 16px !important;
      }
      .btn-whatsapp{
          font-size:16px !important;
  
  }
  }
    @media only screen and (max-width:768px) {
        .chatcol #chat-input {
    padding-left: 42px !important;
}
        .chatcol .iti {
    width: 100%;
    margin-top: 0px  !important;
}
      .textmbcenters {
        text-align: center;
      }
    }


    /* CSS Multiple Whatsapp Chat */
    .whatsapp-name {
      font-size: 16px;
      font-weight: 600;
      padding-bottom: 0;
      margin-bottom: 0;
      line-height: 0.5;
    }

    #whatsapp-chat {
      box-sizing: border-box !important;
      background: #fff;
      outline: none !important;
      position: fixed;
      width: 37%;
      border-radius: 10px;
      box-shadow: 0 1px 15px rgba(32, 33, 36, 0.28);
      bottom: 73px;
      right: 30px;
      overflow: hidden;
      z-index: 100;
      animation-name: showchat;
      animation-duration: 1s;
      transform: scale(1);
    }

    a.blantershow-chat {
      /*   background: #009688; */
      background: #fff;
      color: #404040;
      position: fixed;
      display: flex;
      font-weight: 400;
      justify-content: space-between;
      z-index: 98;
      bottom: 25px;
      right: 30px;
      font-size: 15px;
      padding: 10px 20px;
      border-radius: 30px;
      box-shadow: 0 1px 15px rgba(32, 33, 36, 0.28);
    }

    a.blantershow-chat-1 {
      /*   background: #009688; */
      background: #fff;
      color: #404040;
      position: fixed;
      display: flex;
      font-weight: 400;
      z-index: 100;
      justify-content: space-between;
      z-index: 98;
      bottom: 25px;
      right: 200px;
      font-size: 15px;
      padding: 10px 20px;
      border-radius: 30px;
      box-shadow: 0 1px 15px rgba(32, 33, 36, 0.28);
    }

    a.blantershow-chat svg {
      transform: scale(1.2);
      margin: 0 10px 0 0;
    }

    .header-chat {
      /*   background: linear-gradient(to right top, #6f96f3, #164ed2); */
      background: #009688;
      background: #095e54;
      color: #fff;
      padding: 20px;
    }

    .header-chat h3 {
      margin: 0 0 10px;
    }

    .header-chat p {
      font-size: 14px;
      line-height: 1.7;
      margin: 0;
    }

    .info-avatar {
      position: relative;
    }

    .info-avatar img {
      width: 50px;
      float: left;
      margin: 0 10px 0 0;
    }

    a.informasi {
      padding: 20px;
      display: block;
      overflow: hidden;
      animation-name: showhide;
      animation-duration: 0.5s;
    }

    a.informasi:hover {
      background: #f1f1f1;
    }

    .info-chat span {
      display: block;
    }

    #get-label,
    span.chat-label {
      font-size: 12px;
      color: #888;
    }

    #get-nama,
    span.chat-nama {
      margin: 5px 0 0;
      font-size: 15px;
      font-weight: 700;
      color: #222;
    }

    #get-label,
    #get-nama {
      color: #fff;
    }

    span.my-number {
      display: none;
    }

    /* .blanter-msg {
  color: #444;
  padding: 20px;
  font-size: 12.5px;
  text-align: center;
  border-top: 1px solid #ddd;
} */
    .blanter-msg {
      padding: 20px;
      text-align: center;
    }

    .form-controls {
      /*margin-top: 15px;*/
    }

    input#chat-input,
    .form-controls {
      width: 100%;
      display: block;
      margin: 15px auto 0 auto;
      border: 1px solid #c9c9c9;
      height: 38px;
      border-radius: 20px;
      outline: none;
      resize: none;
      padding: 10px;
      font-size: 14px;
    }

    a#send-it {
      width: 30px;
      font-weight: 700;
      padding: 10px 10px 0;
      background: #eee;
      border-radius: 10px;

      svg {
        fill: #a6a6a6;
        height: 24px;
        width: 24px;
      }
    }

    .first-msg {
      background: transparent;
      padding: 30px;
      text-align: center;

      & span {
        background: #e2e2e2;
        color: #333;
        font-size: 14.2px;
        line-height: 1.7;
        border-radius: 10px;
        padding: 15px 20px;
        display: inline-block;
      }
    }


    #get-number {
      display: none;
    }

    a.close-chat {
      position: absolute;
      top: 5px;
      right: 15px;
      color: #fff;
      font-size: 16px;

    }

    @keyframes ZpjSY {
      0% {
        background-color: rgb(182, 181, 186);
      }

      15% {
        background-color: rgb(17, 17, 17);
      }

      25% {
        background-color: rgb(182, 181, 186);
      }
    }

    @keyframes hPhMsj {
      15% {
        background-color: rgb(182, 181, 186);
      }

      25% {
        background-color: rgb(17, 17, 17);
      }

      35% {
        background-color: rgb(182, 181, 186);
      }
    }

    @keyframes iUMejp {
      25% {
        background-color: rgb(182, 181, 186);
      }

      35% {
        background-color: rgb(17, 17, 17);
      }

      45% {
        background-color: rgb(182, 181, 186);
      }
    }


    @keyframes showhide {
      from {
        transform: scale(0.5);
        opacity: 0;
      }
    }

    @keyframes showchat {
      from {
        transform: scale(0);
        opacity: 0;
      }
    }

    @media screen and (max-width: 480px) {
        .whatsapp-chat-body{
            display:none !important;
        }
        input#chat-input, .form-controls{
                    height: 46px !important;
                margin: 5px auto 0 auto !important;
        }
      #whatsapp-chat {
        width: auto !important;
        left: 5%;
        right: 5%;
        font-size: 80%;
      }
    }

    .hide {
      display: none;
      animation-name: showhide;
      animation-duration: 0.5s;
      transform: scale(1);
      opacity: 1;
    }

    .show {
      display: block;
      animation-name: showhide;
      animation-duration: 0.5s;
      transform: scale(1);
      opacity: 1;
    }

    .whatsapp-message-container {
      display: flex;
      z-index: 1;
    }

    .whatsapp-message {
      padding: 7px 14px 6px;
      background-color: rgb(255, 255, 255);
      border-radius: 0px 8px 8px;
      position: relative;
      transition: all 0.3s ease 0s;
      opacity: 0;
      transform-origin: center top 0px;
      z-index: 2;
      box-shadow: rgba(0, 0, 0, 0.13) 0px 1px 0.5px;
      margin-top: 4px;
      margin-left: -54px;
      max-width: calc(100% - 66px);
    }

    .whatsapp-chat-body {
      padding: 20px 20px 20px 10px;
      background-color: rgb(230, 221, 212);
      position: relative;
    }

    #mywhtasappbutton {
      display: none !important;
    }

    /*.whatsapp-chat-body::before {*/
    /*  display: block;*/
    /*  position: absolute;*/
    /*  content: "";*/
    /*  left: 0px;*/
    /*  top: 0px;*/
    /*  height: 100%;*/
    /*  width: 100%;*/
    /*  z-index: 0;*/
    /*  opacity: 0.08;*/
    /*  background-image: url("./images/whatsapp.webp");*/
    /*}*/

    .scroltop {
      display: none;
    }

    @media only screen and (min-width:0) and (max-width:768px) {
      a.blantershow-chat {
        right: 160px !important;
        font-size: 13px;
        align-items: center;
      }

      a.blantershow-chat-1 {
        right: 7px !important;
        font-size: 13px;
        align-items: center;
      }
    }

    .dAbFpq {
      display: flex;
      z-index: 1;
    }

    .eJJEeC {
      background-color: rgb(255, 255, 255);
      width: 52.5px;
      height: 32px;
      border-radius: 16px;
      display: flex;
      -moz-box-pack: center;
      justify-content: center;
      -moz-box-align: center;
      align-items: center;
      margin-left: 10px;
      opacity: 0;
      transition: all 0.1s ease 0s;
      z-index: 1;
      box-shadow: rgba(0, 0, 0, 0.13) 0px 1px 0.5px;
    }

    .hFENyl {
      position: relative;
      display: flex;
    }

    .ixsrax {
      height: 5px;
      width: 5px;
      margin: 0px 2px;
      border-radius: 50%;
      display: inline-block;
      position: relative;
      animation-duration: 1.2s;
      animation-iteration-count: infinite;
      animation-timing-function: linear;
      top: 0px;
      background-color: rgb(158, 157, 162);
      animation-name: ZpjSY;
    }

    .dRvxoz {

      height: 5px;
      width: 5px;
      margin: 0px 2px;
      background-color: rgb(182, 181, 186);
      border-radius: 50%;
      display: inline-block;
      position: relative;
      animation-duration: 1.2s;
      animation-iteration-count: infinite;
      animation-timing-function: linear;
      top: 0px;
      animation-name: hPhMsj;
    }

    .kAZgZq {
      padding: 7px 14px 6px;
      background-color: rgb(255, 255, 255);
      border-radius: 0px 8px 8px;
      position: relative;
      transition: all 0.3s ease 0s;
      opacity: 0;
      transform-origin: center top 0px;
      z-index: 2;
      box-shadow: rgba(0, 0, 0, 0.13) 0px 1px 0.5px;
      margin-top: 4px;
      margin-left: -54px;
      max-width: calc(100% - 66px);

      &::before {
        position: absolute;
        background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAmCAMAAADp2asXAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAACQUExURUxpccPDw9ra2m9vbwAAAAAAADExMf///wAAABoaGk9PT7q6uqurqwsLCycnJz4+PtDQ0JycnIyMjPf3915eXvz8/E9PT/39/RMTE4CAgAAAAJqamv////////r6+u/v7yUlJeXl5f///5ycnOXl5XNzc/Hx8f///xUVFf///+zs7P///+bm5gAAAM7Ozv///2fVensAAAAvdFJOUwCow1cBCCnqAhNAnY0WIDW2f2/hSeo99g1lBYT87vDXG8/6d8oL4sgM5szrkgl660OiZwAAAHRJREFUKM/ty7cSggAABNFVUQFzwizmjPz/39k4YuFWtm55bw7eHR6ny63+alnswT3/rIDzUSC7CrAziPYCJCsB+gbVkgDtVIDh+DsE9OTBpCtAbSBAZSEQNgWIygJ0RgJMDWYNAdYbAeKtAHODlkHIv997AkLqIVOXVU84AAAAAElFTkSuQmCC");
        background-position: 50% 50%;
        background-repeat: no-repeat;
        background-size: contain;
        content: "";
        top: 0px;
        left: -12px;
        width: 12px;
        height: 19px;
      }
    }

    #mybutton {
      display: none !important;
    }

    .bMIBDo {
      font-size: 13px;
      font-weight: 700;
      line-height: 18px;
      color: rgba(0, 0, 0, 0.4);
    }

    .iSpIQi {
      font-size: 14px;
      line-height: 19px;
      margin-top: 4px;
      color: rgb(17, 17, 17);
    }

    .iSpIQi {
      font-size: 14px;
      line-height: 19px;
      margin-top: 4px;
      color: rgb(17, 17, 17);
    }

    .cqCDVm {
      text-align: right;
      margin-top: 4px;
      font-size: 12px;
      line-height: 16px;
      color:
        rgba(17, 17, 17, 0.5);
      margin-right: -8px;
      margin-bottom: -4px;
    }

    .btn-whatsapp {
      background-color: #4dc247;
      width: 100%;
      border: none;
      margin: auto;
      text-align: center;
      color: #fff;
      padding: 8px 10px;
      border-radius: 18px;
      margin-top: 10px;
      font-size: 16px;
      cursor: pointer;
    }

    .blantershow-chat-1 img {
      width: 20px;
      margin-right: 10px;
    }

    #whtasappbtn {
      display: none;

      background-color: #4dc247;
      border: none;
      margin: auto;
      text-align: center;
      color: #fff;
      padding: 8px 10px;
      border-radius: 18px;
      margin-top: 10px;
      font-size: 16px;
      cursor: pointer;
    }

    @media only screen and (min-width:360px) and (max-width:768px) {
      .iSpIQi {
        font-size: 14px;
        line-height: 12px;
      }
      .header-chat{
          padding:12px;
      }
    }

    #invalidno {
      display: none;
      color: red;
      text-align: center;
      /*font-size: 17px;*/
    }
    .chatcol .iti{
        margin-top: 15px;
    }
    .chatcol #chat-input{
            padding-left: 72px;
    }
    
    .whatsapp-chat-body{
        display:none;
    }
    
    .mlacvnm{
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 30px;
    min-width: 30px;
    padding: 6px 6px;
    box-sizing: border-box;
}
  </style>
  

  <div id='whatsapp-chat' class='hide'>
    <div class='header-chat'>
      <div class='head-home'>
        <div class='info-avatar'><img width="180px" height="109px" src='https://www.mlagroup.com/images/mla-logo.webp' alt="MLA Group" /></div>
        <p><span class="whatsapp-name">MLA Group</span><br></p>

      </div>
      <div class='get-new hide'>
        <div id='get-label'></div>
        <div id='get-nama'></div>
      </div>
    </div>
   
   <input type="hidden" class="countrycode" id="countrycode">
<input type="hidden" class="countrynamev" id="countrynamev">
<input type="hidden" class="cityname" id="cityname">


    <div class='home-chat'>

    </div>
    <div class='start-chat'>
     

      <div class='blanter-msg'>
          <div class="row">
            <div class="col-lg-6">
        <input class="form-controls" id='name-input' type="text" placeholder="Please Enter Your Name*">
        <small id="invalidname" style="color:red" ></small>
        </div>
        
        <div class="col-lg-6">
                <input id='cemail' class="form-controls" type="text" placeholder="Please Enter Email*">
        <small id="cemailerr" style="color:red"></small>
            </div>
      
        </div>
          
        <div class="row">
             
            <div class="col-lg-6 chatcol">
                <input id='chat-input' type="text" class="phone-input" placeholder="Submit Your Number*">
        <small id="invalidno">Please fill correct number</small>
            </div>
             <div class="col-lg-6">
                 <input type="text" class="form-controls" id="companynamev" placeholder="Company Name*">
        <small style="color:red" id="companynameerr"></small>
            </div>
        </div>
        <div class="row">

      
           
        </div>
       
       
        <input type="hidden" value="" id="contact-method">

       
    
        <style>
            #msgfloat{
                height:100% !important;
            }
        </style>
      

        <textarea type="text" class="form-controls" id="msgfloat" placeholder="Message*"></textarea>

        <small style="color:red" id="msgerr"></small>
        <button id="submit-whatsapp" class="btn-whatsapp">Connect On Whatsapp</button>
        <div>
          <a rel="noreferrer" id="whtasappbtn" href="https://api.whatsapp.com/send?phone=919076600122&amp;text=Hi" class="float" target="_blank">Start Chat</a>
        </div>
      </div>
    </div>
    <div id='get-number'></div><a class='close-chat' href='javascript:void'>Close</a>
  </div>
  <a class='blantershow-chat' href='javascript:void' title='Show Chat'><svg width="20" viewBox="0 0 24 24">
      <defs />
      <path fill="#eceff1" d="M20.5 3.4A12.1 12.1 0 0012 0 12 12 0 001.7 17.8L0 24l6.3-1.7c2.8 1.5 5 1.4 5.8 1.5a12 12 0 008.4-20.3z" />
      <path fill="#4caf50" d="M12 21.8c-3.1 0-5.2-1.6-5.4-1.6l-3.7 1 1-3.7-.3-.4A9.9 9.9 0 012.1 12a10 10 0 0117-7 9.9 9.9 0 01-7 16.9z" />
      <path fill="#fafafa" d="M17.5 14.3c-.3 0-1.8-.8-2-.9-.7-.2-.5 0-1.7 1.3-.1.2-.3.2-.6.1s-1.3-.5-2.4-1.5a9 9 0 01-1.7-2c-.3-.6.4-.6 1-1.7l-.1-.5-1-2.2c-.2-.6-.4-.5-.6-.5-.6 0-1 0-1.4.3-1.6 1.8-1.2 3.6.2 5.6 2.7 3.5 4.2 4.2 6.8 5 .7.3 1.4.3 1.9.2.6 0 1.7-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.3-.6-.4z" />
    </svg> Chat with Us</a>


  <a class="blantershow-chat-1 GAFloatCallButton" href="javascript:void" title="Show Chat"><img src="images/telephone.webp" alt="call now"> Call Us Now</a>


  <style>
    .anu-hed {
      font-size: 1.125rem;
      color: var(--title);
    }
  
  </style>
  <!-- Footer Top -->
  <div class="footer-top">
    <div class="container">
      <div class="row ">
        <div class="col-xl-5 col-md-3 col-sm-6 textmbcenters">
          <div class="widget widget_about me-2">
            <div class="footer-logo logo-white">
              <a href="/"><img src="images/mla-logo.webp" alt="Footer Logo
"></a>
            </div>
            <ul class="widget-address">
              <li>
                <p><span>Address</span> : 111/230, Harsh Nagar, Kanpur-208012 (INDIA) </p>
              </li>
              <li>
                <p><span>E-mail</span> :<a class="wp-open" href="javascript:void(0)"> md@mlagroup.com</a>
                </p>
              </li>
              <li>
                <p><span>Phone</span> : <a class="call-open" href="javascript:void(0)">+91-9076600122 </a></p>
              </li>
            </ul>

          </div>
        </div>

        <div class="col-xl-3 col-md-3 col-sm-4 col-6">
          <div class="widget widget_services">
            <p class="footer-title anu-hed">Quick Links</p>
            <ul>
              <li><a class="bleft mlacvnm" href="/">Home</a></li>
              <li><a class="bleft mlacvnm" href="about">About Us</a></li>
              <li><a class="bleft mlacvnm" href="r-and-d">R & D</a></li>
              <li><a class="bleft mlacvnm" href="qc">Quality</a></li>
              <li><a class="bleft mlacvnm" href="manufacturing">Manufacturing</a></li>
              <li><a class="bleft mlacvnm" href="contact-us">Contact Us</a></li>

            </ul>
          </div>
        </div>
        <div class="col-xl-4 col-md-6 col-sm-4 col-6">
          <div class="widget widget_services">
            <p class="footer-title text-center anu-hed" style="text-transform: uppercase;">We exhibit at</p>
            <div class="section-inner">

              <div class="row gx-3 companies-inner ">
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp " data-wow-delay="0.1s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/veitnamplas.webp" alt="Vietnamplas" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.2s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/chinaplas.webp" alt="Chinaplas" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.3s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/arab-plast.webp" alt="Arab Plast" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.4s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/make-the-difference.webp" alt="Make the Difference" clas="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.5s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/kenya-plast.webp" alt="Kenya Plast" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.6s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/plast-india.webp" alt="Plast India" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.6s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/plastvision.webp" alt="Plast Vision" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>
                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.6s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/india-rubber-expo.webp" alt="India Rubber Expo" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>

                <div class="col-md-4 col-sm-4 col-6 p-lg-b30 p-b20 wow fadeInUp" data-wow-delay="0.6s">
                  <!--<a href="javascript:void(0);" class="companies-wrapper">-->
                    <div class="companies-media">
                      <img loading="lazy" height="43" width="94" src="images/cphlindia.webp" alt="CPHL India" class="logo-foot">
                    </div>
                  <!--</a>-->
                </div>

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <!-- Footer Top End -->

  <!-- Footer Bottom -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row fb-inner">
        <div class="col-lg-12 col-md-12 text-start">
          <p class="copyright-text">Copyright © MLA Group of Industries <?php echo date("Y"); ?> </p>
        </div>

      </div>
    </div>
  </div>
  <!-- Footer Bottom End -->

</footer>
<!-- Footer End -->

<!-- <button class="scroltop" type="button"><i class="fas fa-arrow-up"></i></button> -->


</div>


<!-- JAVASCRIPT FILES ========================================= -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script defer src="vendor/wow/wow.min.js"></script><!-- WOW JS -->
<script src="vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script><!-- BOOTSTRAP MIN JS -->
<!-- <script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>BOOTSTRAP SELECT MIN JS -->
<!-- <script src="vendor/bootstrap-touchspin/bootstrap-touchspin.js"></script>BOOTSTRAP TOUCHSPIN JS -->

<script defer src="vendor/counter/waypoints-min.js"></script><!-- WAYPOINTS JS -->
<!-- <script src="vendor/counter/counterup.min.js"></script>COUNTERUP JS -->

<script defer src="vendor/swiper/swiper-bundle.min.js"></script>
<!-- <script src="vendor/imagesloaded/imagesloaded.js"></script>IMAGESLOADED -->
<!-- <script src="vendor/masonry/masonry-4.2.2.js"></script>MASONRY -->
<!-- <script src="vendor/masonry/isotope.pkgd.min.js"></script>ISOTOPE -->
<!-- <script src="vendor/countdown/jquery.countdown.js"></script>COUNTDOWN FUCTIONS  -->
<!-- <script src="vendor/wnumb/wNumb.js"></script>WNUMB -->

<!-- <script src="vendor/nouislider/nouislider.min.js"></script> -->

<script defer src="js/dz.carousel.js"></script><!-- DZ CAROUSEL JS -->
<!-- <script src="vendor/lightgallery/dist/lightgallery.min.js"></script> -->
<!-- <script src="vendor/lightgallery/dist/plugins/thumbnail/lg-thumbnail.min.js"></script> -->
<!-- <script src="vendor/lightgallery/dist/plugins/zoom/lg-zoom.min.js"></script> -->
<!-- <script src="js/dz.ajax.js"></script>AJAX -->
<script defer src="js/custom.js"></script><!-- CUSTOM JS -->


<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.css" integrity="sha512-Woz+DqWYJ51bpVk5Fv0yES/edIMXjj3Ynda+KWTIkGoynAMHrqTcDUQltbipuiaD5ymEo9520lyoVOo9jCQOCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />-->

<script>
  // document.addEventListener("DOMContentLoaded", function (event) {
  //     setTimeout(function () {
  //         document.getElementById('typing-text').style.animationPlayState = 'running';
  //     }, 1000); // Delaying animation start by 1 second
  


document.querySelectorAll(".phone-input").forEach(function(input) {
  let iti = window.intlTelInput(input, {
    initialCountry: "auto",
    geoIpLookup: function(callback) {
      fetch("https://ipapi.co/json")
        .then(res => res.json())
        .then(data =>{
        console.log("IP API Response:", data);
         document.querySelectorAll("#cityname").forEach(el => el.value = data.city);
      document.querySelectorAll("#countrynamev").forEach(el => el.value = data.country_name);

        callback(data.country_code)})
        .catch(() => callback("us"));
    },
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
  });

  // function to update ALL hidden fields
  function updateAllCountryCodes() {
    let data = iti.getSelectedCountryData();

    // Dial code with +
    if(document.querySelector("#ccods")){
    document.querySelector("#ccods").value = "+" + data.dialCode;
    }
    document.querySelectorAll("#countrycode").forEach(function(el) {
        el.value = "+" + data.dialCode;
    });

    // Country name from selected flag
    document.querySelectorAll("#countrynamev").forEach(function(el) {
        el.value = data.name;
    });
}


  // Initial set
  updateAllCountryCodes();

  // Update whenever country changes
  input.addEventListener("countrychange", updateAllCountryCodes);
});



  $("#chat-input").on('keyup', function() {

    let phonnumber = $(this).val();
    console.log(phonnumber.length);
    // var regx = /^[6-9]\d{9}$/;
    if (phonnumber) {

     
        var contactmethod = $('#contact-method').val();
        if (contactmethod == 'call') {
          $("#submit-whatsapp").addClass("GAFloatCallButton")
          $("#submit-whatsapp").removeClass("GAFloatWAppButton")


        }
        if (contactmethod == 'whatsapp') {
          $("#submit-whatsapp").addClass("GAFloatWAppButton")
          $("#submit-whatsapp").removeClass("GAFloatCallButton")
        }
      }
     
  })



  $('#submit-whatsapp').on('click', function() {
    var isValid = true;
    const pageUrl = window.location.href;
    var nameRegex = /^[A-Za-z\s]+$/;
    var phone = document.getElementById("chat-input").value;
    var regx = /^(\+?\d{1,3})?[6-9]\d{6,14}$/;
   
    var msgfloat = document.querySelector("#msgfloat");
    // var producterr = document.querySelector("#producterr");
    var msgerr = document.querySelector("#msgerr");
    
    var nameinput = document.querySelector("#name-input");
   
    var nameinputerr = document.querySelector("#invalidname");
   
      var companynamev = document.querySelector("#companynamev");
    var companynameerr = document.querySelector("#companynameerr");
    
    var cemail= document.querySelector("#cemail");
    var cemailerr = document.querySelector("#cemailerr");
    
 
 
    
    if (cemail.value.trim() === '') {
      cemailerr.textContent = 'Please enter email';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(cemail.value.trim())) {
      cemailerr.textContent = 'Please enter email';
      isValid = false;
    } else {
      cemailerr.textContent = ''; // Clear the error if validation passes
    }
    
  
  
    if (companynamev.value.trim() === '') {
      companynameerr.textContent = 'Please enter company name';
      isValid = false;
    } else if (!nameRegex.test(companynamev.value.trim())) {
      companynameerr.textContent = 'Please enter company name';
      isValid = false;
    } else {
      companynameerr.textContent = ''; // Clear the error if validation passes
    }
    
    
     if (nameinput.value.trim() === '') {
      nameinputerr.textContent = 'Please Enter Name';
      isValid = false;
    } else {
      nameinputerr.textContent = ''; // Clear the error if validation passes
    }
    
    
    

    if (!regx.test(phone)) {
      $("#invalidno").show();
    } else {
      $("#invalidno").hide();
    }



    if (msgfloat.value.trim() === '') {
      msgerr.textContent = 'Please enter message';
      isValid = false;
    } else {
      msgerr.textContent = ''; // Clear the error if validation passes
    }

  


    // alert("hey")
    
    
    var countrynamev = $("#countrynamev").val();
var cityname = $("#cityname").val();
var dialcode = $("#countrycode").val();   // already includes "+"



    if (regx.test(phone) && isValid) {
        // alert("hey2")
      $("#invalidno").hide();
       var cpname = companynamev.value;
      var contactmethod = $('#contact-method').val();

    //   var productid = productid.value;
      var msgv = msgfloat.value;

    
    //   var countrycode = $("#floatcountrycode").val();

      const scriptURL = 'https://script.google.com/macros/s/AKfycbyDXiwzM87ZSTG-Wa8993adTRmmpaOe9-AUxoC1ahAPD1ZEHEiex6vZy1xVOuwnhJ6MjQ/exec'
      var formData = new FormData();


      formData.append('Method', contactmethod);
      formData.append('Phone', "+" + dialcode + phone);
      formData.append('Name', nameinput.value);


      formData.append('url', window.location.href);
      formData.append('source', 'Seo');
      formData.append('Countrycode', cityname);
      formData.append('country', countrynamev);
      const currentDate = new Date();

      const formattedDateTime = currentDate.toLocaleString('en-US', {
        weekday: 'short', // Tue
        year: 'numeric', // 2025
        month: 'short', // Jul
        day: 'numeric', // 8
        hour: '2-digit', // 07
        minute: '2-digit', // 29
        second: '2-digit', // 19
        hour12: true // Enforces 12-hour format with AM/PM
      });
        const formattedDateTimemonth = currentDate.toLocaleString('en-US', {
             
                month: 'short',
               
            });
      
      formData.append('month', formattedDateTimemonth)

      console.log(formattedDateTime);
      formData.append('date', formattedDateTime);




     function sendgdataSheet(){
        //  alert("hfh")
       fetch(scriptURL, {
          method: 'POST',
          body: formData,
          headers: {
            'Accept': 'application/json',

          },
        })
        .then(response => response.json())
        .then(data => {
          if (data.result === 'success') {
            console('Form submitted successfully!');
          } else {
            console('Error: ' + data.error);
          }
        })
        .catch(error => console('Error: ' + error.message));
     }

        if(countrynamev){
      //   alert(phone);

      $.ajax({
        url: "https://www.mlagroup.com/contact-us-submit-floater",
        method: "post",
        data: {
        nameinput:nameinput.value,
       
        cemail:cemail.value,
          phone: phone,
          contactmethod: contactmethod,
          pageUrl: pageUrl,
          countrynamev: countrynamev,
          countrycode: dialcode,
          ccity:cityname,
          companynamev:cpname,
          msg: msgv,
          csrf_token: "<?php echo hash_hmac('sha256', 'send_mail', $_SERVER['REMOTE_ADDR'] . 'MLAGROUPMM123'); ?>",

          action: 'phone-number-submit'
        },
        beforeSend: function() {
          // setting a timeout
          $("#submit-whatsapp").attr("disabled", true);
          $("#submit-whatsapp").text("Sending......")
        },
        success: function(data) {
          if (data.success) {
            sendgdataSheet();
            // $('#chat-input').hide();
            $("#submit-whatsapp").attr("disabled", false);
          $("#submit-whatsapp").text("Submit")
            // $('#whtasappbtn').css('display', 'block');
            $('#submit-whatsapp').hide();
            var contactmethod = $('#contact-method').val();
            if (contactmethod == 'call') {

              location.href = "tel:9076600122";

            }
            if (contactmethod == 'whatsapp') {
              location.href = "https://api.whatsapp.com/send?phone=919076600122&amp;text=Hi";
            }
            if (contactmethod == 'call2') {
              location.href = "tel:9076600122";
            }
            if (contactmethod == 'whatsappfootercontact') {
              location.href = "https://api.whatsapp.com/send?phone=919076600122&amp;text=Hi";
            }
          }
          else{
            alert(data.message);
            $("#submit-whatsapp").attr("disabled", false);
          $("#submit-whatsapp").text("Submit")
          }
       
        }

      });
    }
    }
  });


  $(document).on("click", ".close-chat", function() {
      $("#whatsapp-chat")
        .addClass("hide")
        .removeClass("show");
    }),

    $(document).on("click", ".blantershow-chat-1, .call-open", function() {
      $("#whatsapp-chat")
        .addClass("show")
        .removeClass("hide");
      $('#submit-whatsapp').removeClass("GAFloatWAppButton");
      $('#submit-whatsapp').removeClass("GAFloatCallButton");
      $("#contact-method").val("call");

      var contactmethod = $('#contact-method').val();

      let phonnumber = $("#chat-input").val();


      if (phonnumber.length > "6" && phonnumber.length < "15") {
        $('#submit-whatsapp').addClass("GAFloatCallButton");
      }

      if (contactmethod == 'call') {
        $('#submit-whatsapp').text("Connect On Call");
        $('.header-chat').css('background', 'rgb(113 107 100)');
        $('.btn-whatsapp').css('background', 'rgb(76 75 73)');
        $('.whatsapp-chat-body').css('display', 'none');
      } else {
        $('#submit-whatsapp').text("Connect On Whatsapp");
        $('.header-chat').css('background', '#095e54');
        $('.btn-whatsapp').css('background', '#4dc247');
        $('.whatsapp-chat-body').css('display', 'block');
      }

    });
  $(document).on("click", ".blantershow-chat, .wp-open", function() {
    $("#whatsapp-chat")
      .addClass("show")
      .removeClass("hide");
    $("#contact-method").val("whatsapp");
    var contactmethod = $('#contact-method').val();
    $('#submit-whatsapp').removeClass("GAFloatWAppButton");
    $('#submit-whatsapp').removeClass("GAFloatCallButton");

    var contactmethod = $('#contact-method').val();

    let phonnumber = $("#chat-input").val();

    if (phonnumber.length == "10") {
      $('#submit-whatsapp').addClass("GAFloatWAppButton");
    }

    if (contactmethod == 'call') {
      $('#submit-whatsapp').text("Connect On Call");
      $('.header-chat').css('background', 'rgb(113 107 100)');
      $('.btn-whatsapp').css('background', 'rgb(76 75 73)');
      $('.whatsapp-chat-body').css('display', 'none');
    } else {
      $('#submit-whatsapp').text("Connect On Whatsapp");
      $('.header-chat').css('background', '#095e54');
      $('.btn-whatsapp').css('background', '#4dc247');
      $('.whatsapp-chat-body').css('display', 'block');
    }
  });

  $('.popupone').on('click', function() {
    var number = $(this).text();
    $("#mynumberone").val(number);
    $("#whatsapp-chat")
      .addClass("show")
      .removeClass("hide");
    $('#submit-whatsapp').removeClass("GAFloatWAppButton");
    $('#submit-whatsapp').removeClass("GAFloatCallButton");
    $("#contact-method").val("call");

    var contactmethod = $('#contact-method').val();

    let phonnumber = $("#chat-input").val();


    if (phonnumber.length > "6" && phonnumber.length < "15") {
      $('#submit-whatsapp').addClass("GAFloatCallButton");
    }


    if (contactmethod == 'call') {
      $('#submit-whatsapp').text("Connect On Call");
      $('.header-chat').css('background', 'rgb(113 107 100)');
      $('.btn-whatsapp').css('background', 'rgb(76 75 73)');
      $('.whatsapp-chat-body').css('display', 'none');
    }

  });

  $('.whatsapp-footer-contact').on('click', function() {
    $("#whatsapp-chat")
      .addClass("show")
      .removeClass("hide");
    $("#contact-method").val("whatsappfootercontact");
    var contactmethod = $('#contact-method').val();
    if (contactmethod == 'whatsappfootercontact') {
      $('#submit-whatsapp').text("Connect On Whatsapp");
      $('.header-chat').css('background', '#095e54');
      $('.btn-whatsapp').css('background', '#4dc247');
      $('.whatsapp-chat-body').css('display', 'block');
    }

  });

  $(document).on("click", ".rahul1", function() {
    $("#whatsapp-chat")
      .addClass("show")
      .removeClass("hide");
    $('#submit-whatsapp').removeClass("GAFloatWAppButton");
    $('#submit-whatsapp').removeClass("GAFloatCallButton");
    $("#contact-method").val("call");

    var contactmethod = $('#contact-method').val();

    let phonnumber = $("#chat-input").val();


    if (phonnumber.length > "6" && phonnumber.length < "15") {
      $('#submit-whatsapp').addClass("GAFloatCallButton");
    }

    if (contactmethod == 'call') {
      $('#submit-whatsapp').text("Connect On Call");
      $('.header-chat').css('background', 'rgb(113 107 100)');
      $('.btn-whatsapp').css('background', 'rgb(76 75 73)');
      $('.whatsapp-chat-body').css('display', 'none');
    } else {
      $('#submit-whatsapp').text("Connect On Whatsapp");
      $('.header-chat').css('background', '#095e54');
      $('.btn-whatsapp').css('background', '#4dc247');
      $('.whatsapp-chat-body').css('display', 'block');
    }

  });
  $(document).on("click", ".wapopup", function() {
    $("#whatsapp-chat")
      .addClass("show")
      .removeClass("hide");
    $("#contact-method").val("whatsapp");
    var contactmethod = $('#contact-method').val();
    $('#submit-whatsapp').removeClass("GAFloatWAppButton");
    $('#submit-whatsapp').removeClass("GAFloatCallButton");

    var contactmethod = $('#contact-method').val();

    let phonnumber = $("#chat-input").val();

    if (phonnumber.length > "6" && phonnumber.length < "15") {
      $('#submit-whatsapp').addClass("GAFloatWAppButton");
    }

    if (contactmethod == 'call') {
      $('#submit-whatsapp').text("Connect On Call");
      $('.header-chat').css('background', 'rgb(113 107 100)');
      $('.btn-whatsapp').css('background', 'rgb(76 75 73)');
      $('.whatsapp-chat-body').css('display', 'none');
    } else {
      $('#submit-whatsapp').text("Connect On Whatsapp");
      $('.header-chat').css('background', '#095e54');
      $('.btn-whatsapp').css('background', '#4dc247');
      $('.whatsapp-chat-body').css('display', 'block');
    }
  });


  $(document).ready(function() {
    function animateCounters() {
      $('.counter-value').each(function() {
        $(this).prop('Counter', 0).animate({
          Counter: $(this).text()
        }, {
          duration: 2500,
          easing: 'swing',
          step: function(now) {
            $(this).text(Math.ceil(now));
          }
        });
      });
    }

    function checkViewport() {
      if ($('.counternew')) {
        if (isElementInViewport($('.counternew')[0])) {
          if (!$('.counternew').hasClass('animated')) {
            $('.counternew').addClass('animated');
            animateCounters();
          }
        } else {
          $('.counternew').removeClass('animated');
        }
      }
    }

    $(window).on('scroll', checkViewport);

    // Trigger the function once in case the element is already in view
    checkViewport();
  });

  function isElementInViewport(el) {
    if (el) {
      var rect = el.getBoundingClientRect();
      return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
      );
    }
  }




  document.addEventListener("DOMContentLoaded", function() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        } else {
          entry.target.classList.remove('visible');
        }
      });
    });

    const target = document.querySelector('.zoom-in-up');
    if (target) {
      observer.observe(target);
    }

  });


  // function showYouTubeVideo() {

  //     var youtubeUrl = document.getElementById('ytbplay').getAttribute('data-url');

  //     var iframe = document.createElement('iframe');
  //     iframe.setAttribute('width', '100%');
  //     iframe.setAttribute('height', '315');
  //     iframe.setAttribute('src', 'https://www.youtube.com/embed/' + youtubeUrl);
  //     iframe.setAttribute('frameborder', '0');
  //     iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
  //     iframe.setAttribute('allowfullscreen', '');


  //     document.querySelector('.modal-body').appendChild(iframe);
  // }


  // document.getElementById('ytbplay').addEventListener('click', showYouTubeVideo);


  var swiper = new Swiper('.swiper-container-sliding', {
    direction: 'horizontal',
    loop: true,
    speed: 20000,
    autoplay: {
      delay: 0,
      disableOnInteraction: false,
      reverseDirection: true,
    },
    slidesPerView: 'auto',
    spaceBetween: 20,
    allowTouchMove: false,
    effect: 'slide',

  });
</script>


<script>
document.addEventListener("DOMContentLoaded", () => {
  var slider = new Swiper(".gallery-slider", {
    slidesPerView: 1,
    loop: true,
    loopedSlides: 6,
    noSwiping: true,
    keyboard: {
      enabled: true
    },

    noSwipingClass: "swiper-slide",
    pagination: {
      el: ".swiper-pagination",
      clickable: true
    }
  });

  var thumbs = new Swiper(".gallery-thumbs", {
    slidesPerView: "auto",
    spaceBetween: 10,
    centeredSlides: false,
    loop: true,
    slideToClickedSlide: true
  });

  slider.controller.control = thumbs;
  thumbs.controller.control = slider;
  
  
  var mainalleyslider = new Swiper(".mainalleyslider", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    speed: 800,
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".mainalleyslider .swiper-pagination",
        clickable: true,
    },
});
});
</script>

<script>
  window.addEventListener('load', function() {
    function animateCounters(counterElements) {
      const totalDuration = 2000; // Total duration for all counters in milliseconds

      counterElements.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        const startTime = performance.now();

        function updateCount(currentTime) {
          const elapsedTime = currentTime - startTime;
          const progress = Math.min(elapsedTime / totalDuration, 1); // Progress ranges from 0 to 1
          const currentCount = Math.ceil(progress * target);

          counter.innerText = currentCount;

          if (progress < 1) {
            requestAnimationFrame(updateCount); // Continue the animation
          } else {
            counter.innerText = target; // Ensure the counter reaches the target exactly
          }
        }

        requestAnimationFrame(updateCount);
      });
    }

    function resetCounters(counterElements) {
      counterElements.forEach(counter => {
        counter.innerText = '0';
      });
    }

    let options = {
      root: null,
      rootMargin: '0px',
      threshold: 0.5
    };

    let observer = new IntersectionObserver(function(entries, observer) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            const counters = entry.target.querySelectorAll('.counter');
            resetCounters(counters);
            animateCounters(counters);
          }, 500); // Adjust this to match your wow.js delay
        } else {
          const counters = entry.target.querySelectorAll('.counter');
          resetCounters(counters);
        }
      });
    }, options);

    let counterSection = document.querySelector('#counter-section');
    if (counterSection) {
      observer.observe(counterSection);
    }

  });
  document.addEventListener("DOMContentLoaded", function () {
  const swipers = new Swiper(".mySwipers", {
    loop: true,
    spaceBetween: 20,

    slidesPerView: 1,

    breakpoints: {
        576: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        992: {
            slidesPerView: 3,
        }
    },

    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },

    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

    autoplay: {
        delay: 3000,
        disableOnInteraction: true,
    },

    speed: 700,
});

const swiperst = new Swiper(".mySwipers1", {
    loop: true,
    spaceBetween: 20,

    slidesPerView: 1,

    breakpoints: {
        576: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        992: {
            slidesPerView: 2,
        }
    },

    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },

    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

  
});

});

</script>



</body>



</html>